import { createContext, useState, useEffect, useCallback } from 'react';
import { STORAGE_KEYS } from '../utils/session';

export const CartContext = createContext(null);

function loadCart() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.CART)) || [];
  } catch {
    return [];
  }
}

function persist(items) {
  localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(items));
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadCart);

  // Sync to localStorage whenever items change
  useEffect(() => { persist(items); }, [items]);

  const addToCart = useCallback((product) => {
    setItems(prev => {
      const exists = prev.find(i => i.id === product.id);
      if (exists) return prev; // prevent duplicates
      return [...prev, { ...product, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((id) => {
    setItems(prev => prev.filter(i => i.id !== id));
  }, []);

  const increaseQty = useCallback((id) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, quantity: i.quantity + 1 } : i));
  }, []);

  const decreaseQty = useCallback((id) => {
    setItems(prev =>
      prev.map(i => i.id === id ? { ...i, quantity: Math.max(1, i.quantity - 1) } : i)
    );
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  const isInCart = useCallback((id) => items.some(i => i.id === id), [items]);

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider value={{
      items, addToCart, removeFromCart, increaseQty, decreaseQty,
      clearCart, isInCart, total, totalItems,
    }}>
      {children}
    </CartContext.Provider>
  );
}
