import { createContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  createSession, getSession, clearSession,
  findUserByEmail, getUsers, saveUsers,
  getSessionRemaining, SESSION_DURATION,
} from '../utils/session';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sessionRemaining, setSessionRemaining] = useState(0);
  const timerRef = useRef(null);

  // Boot: restore session
  useEffect(() => {
    const session = getSession();
    if (session) {
      setUser({ name: session.name, email: session.email });
      setSessionRemaining(getSessionRemaining());
    }
    setLoading(false);
  }, []);

  // Countdown timer
  useEffect(() => {
    if (!user) {
      clearInterval(timerRef.current);
      setSessionRemaining(0);
      return;
    }
    timerRef.current = setInterval(() => {
      const remaining = getSessionRemaining();
      setSessionRemaining(remaining);
      if (remaining <= 0) {
        logout();
      }
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [user]);

  const login = useCallback(({ email, password }) => {
    const found = findUserByEmail(email);
    if (!found || found.password !== password) {
      return { success: false, error: 'Invalid email or password.' };
    }
    const session = createSession(found);
    setUser({ name: found.name, email: found.email });
    setSessionRemaining(SESSION_DURATION);
    return { success: true };
  }, []);

  const register = useCallback(({ name, email, password }) => {
    const existing = findUserByEmail(email);
    if (existing) return { success: false, error: 'An account with this email already exists.' };
    const users = getUsers();
    users.push({ name, email, password });
    saveUsers(users);
    return { success: true };
  }, []);

  const logout = useCallback(() => {
    clearSession();
    clearInterval(timerRef.current);
    setUser(null);
    setSessionRemaining(0);
  }, []);

  const updateUser = useCallback((updates) => {
    setUser(prev => ({ ...prev, ...updates }));
    // Re-create session with updated name/email
    const raw = localStorage.getItem('shopdash_session');
    if (raw) {
      const session = JSON.parse(raw);
      const updated = { ...session, ...updates };
      localStorage.setItem('shopdash_session', JSON.stringify(updated));
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, sessionRemaining, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}
