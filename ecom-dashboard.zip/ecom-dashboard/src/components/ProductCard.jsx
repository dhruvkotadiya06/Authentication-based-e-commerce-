import { useState } from 'react';
import { useCart } from '../hooks/useCart';

export default function ProductCard({ product }) {
  const { addToCart, isInCart } = useCart();
  const [imgLoaded, setImgLoaded] = useState(false);
  const inCart = isInCart(product.id);

  const categoryColor = {
    "men's clothing": 'bg-blue-100 text-blue-700',
    "women's clothing": 'bg-pink-100 text-pink-700',
    "jewelery": 'bg-yellow-100 text-yellow-700',
    "electronics": 'bg-purple-100 text-purple-700',
  }[product.category] || 'bg-surface-muted text-ink-muted';

  return (
    <div className="card flex flex-col group hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 overflow-hidden animate-fade-in">
      {/* Image */}
      <div className="relative bg-surface h-52 flex items-center justify-center p-6 overflow-hidden">
        {!imgLoaded && <div className="skeleton absolute inset-0 rounded-t-2xl" />}
        <img
          src={product.image}
          alt={product.title}
          onLoad={() => setImgLoaded(true)}
          className={`max-h-40 object-contain transition-all duration-300 group-hover:scale-105 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
        />
        <span className={`absolute top-3 right-3 text-xs font-semibold px-2 py-0.5 rounded-full ${categoryColor}`}>
          {product.category}
        </span>
      </div>

      {/* Body */}
      <div className="flex flex-col flex-1 p-5 gap-3">
        <h3 className="text-sm font-semibold text-ink leading-snug line-clamp-2 flex-1">
          {product.title}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-1.5">
          <div className="flex">
            {[1,2,3,4,5].map(i => (
              <svg key={i} className={`w-3.5 h-3.5 ${i <= Math.round(product.rating.rate) ? 'text-amber-400' : 'text-surface-muted'}`} fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
          </div>
          <span className="text-xs text-ink-muted">{product.rating.rate} ({product.rating.count})</span>
        </div>

        {/* Price + button */}
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-surface-muted">
          <span className="font-display text-xl font-bold text-ink">${product.price.toFixed(2)}</span>
          <button
            onClick={() => addToCart(product)}
            disabled={inCart}
            className={`text-xs font-semibold px-4 py-2 rounded-xl transition-all duration-150 active:scale-95
              ${inCart
                ? 'bg-green-100 text-green-700 cursor-default'
                : 'bg-brand-600 hover:bg-brand-700 text-white shadow-sm shadow-brand-200'}`}
          >
            {inCart ? (
              <span className="flex items-center gap-1.5">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                Added
              </span>
            ) : 'Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}
