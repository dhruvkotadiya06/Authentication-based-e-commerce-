import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

function validate({ name, email, password }) {
  if (!name.trim() || name.trim().length < 2) return 'Name must be at least 2 characters.';
  if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Please enter a valid email.';
  if (!password || password.length < 6) return 'Password must be at least 6 characters.';
  return null;
}

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [show, setShow] = useState(false);

  const handleChange = e => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = e => {
    e.preventDefault();
    setError('');
    const err = validate(form);
    if (err) { setError(err); return; }
    const result = register(form);
    if (!result.success) { setError(result.error); return; }
    setSuccess(true);
    setTimeout(() => navigate('/login'), 1500);
  };

  return (
    <div className="min-h-screen bg-surface flex">
      {/* Left decorative panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-ink flex-col justify-center px-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, #5a5ef7 0%, transparent 50%), radial-gradient(circle at 80% 80%, #7585ff 0%, transparent 40%)'
        }} />
        <div className="relative z-10">
          <span className="font-display font-bold text-4xl text-white">Shop<span className="text-brand-400">Dash</span></span>
          <p className="text-white/50 mt-3 text-lg leading-relaxed">Your all-in-one e-commerce management dashboard.</p>
          <div className="mt-12 grid grid-cols-2 gap-4">
            {['Manage Products', 'Track Orders', 'Cart System', 'Profile Control'].map(f => (
              <div key={f} className="bg-white/5 border border-white/10 rounded-xl px-4 py-3">
                <span className="text-sm text-white/70 font-medium">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md animate-slide-up">
          <div className="lg:hidden mb-8">
            <span className="font-display font-bold text-3xl text-ink">Shop<span className="text-brand-600">Dash</span></span>
          </div>

          <h1 className="font-display text-3xl font-bold text-ink mb-1">Create account</h1>
          <p className="text-sm text-ink-muted mb-8">Already have an account? <Link to="/login" className="text-brand-600 font-semibold hover:underline">Sign in</Link></p>

          {success && (
            <div className="mb-6 flex items-center gap-3 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm font-medium animate-fade-in">
              <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
              Account created! Redirecting to login…
            </div>
          )}

          {error && (
            <div className="mb-6 flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium animate-fade-in">
              <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">Full name</label>
              <input name="name" type="text" autoComplete="name" placeholder="Jane Doe"
                value={form.name} onChange={handleChange}
                className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">Email address</label>
              <input name="email" type="email" autoComplete="email" placeholder="jane@example.com"
                value={form.email} onChange={handleChange}
                className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">Password</label>
              <div className="relative">
                <input name="password" type={show ? 'text' : 'password'} autoComplete="new-password" placeholder="Min 6 characters"
                  value={form.password} onChange={handleChange}
                  className="input-field pr-12" />
                <button type="button" onClick={() => setShow(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink">
                  {show
                    ? <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
                    : <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  }
                </button>
              </div>
            </div>
            <button type="submit" className="btn-primary w-full mt-2 text-base py-3">
              Create account
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
