import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { findUserByEmail, updateUserByEmail } from '../utils/session';

function validate({ name, email, password, newPassword }) {
  if (!name.trim() || name.trim().length < 2) return 'Name must be at least 2 characters.';
  if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Please enter a valid email.';
  if (newPassword && newPassword.length < 6) return 'New password must be at least 6 characters.';
  return null;
}

export default function Profile() {
  const { user, updateUser } = useAuth();
  const stored = findUserByEmail(user.email) || {};

  const [form, setForm] = useState({
    name: user.name || '',
    email: user.email || '',
    currentPassword: '',
    newPassword: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [saving, setSaving] = useState(false);
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);

  const handleChange = e => {
    setError('');
    setSuccess('');
    setForm(p => ({ ...p, [e.target.name]: e.target.value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const err = validate(form);
    if (err) { setError(err); return; }

    // Verify current password if changing password
    if (form.newPassword) {
      if (!form.currentPassword) { setError('Please enter your current password to change it.'); return; }
      if (stored.password !== form.currentPassword) { setError('Current password is incorrect.'); return; }
    }

    setSaving(true);
    setTimeout(() => {
      const updates = {
        name: form.name.trim(),
        email: form.email.trim(),
        ...(form.newPassword ? { password: form.newPassword } : {}),
      };
      updateUserByEmail(user.email, updates);
      updateUser({ name: updates.name, email: updates.email });
      setForm(p => ({ ...p, currentPassword: '', newPassword: '' }));
      setSuccess('Profile updated successfully!');
      setSaving(false);
    }, 500);
  };

  return (
    <main className="p-6 lg:p-10 max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-8 animate-slide-up">
        <p className="text-sm text-brand-600 font-semibold mb-1">Account</p>
        <h1 className="font-display text-3xl font-bold text-ink">Your Profile</h1>
        <p className="text-ink-muted mt-1">Manage your personal information and password.</p>
      </div>

      {/* Avatar card */}
      <div className="card p-6 mb-6 flex items-center gap-5 animate-slide-up" style={{ animationDelay: '0.05s' }}>
        <div className="w-16 h-16 rounded-2xl bg-brand-600 flex items-center justify-center text-white font-display font-bold text-2xl shrink-0">
          {user?.name?.charAt(0).toUpperCase()}
        </div>
        <div>
          <p className="font-display font-bold text-xl text-ink">{user?.name}</p>
          <p className="text-sm text-ink-muted">{user?.email}</p>
          <span className="inline-flex items-center gap-1.5 mt-1 text-xs bg-brand-100 text-brand-700 font-semibold px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-500 inline-block" />
            Active session
          </span>
        </div>
      </div>

      {/* Form */}
      <div className="card p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
        <h2 className="font-display font-bold text-base text-ink mb-5">Edit Information</h2>

        {success && (
          <div className="mb-5 flex items-center gap-3 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm font-medium animate-fade-in">
            <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
            {success}
          </div>
        )}

        {error && (
          <div className="mb-5 flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium animate-fade-in">
            <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-ink mb-1.5">Full name</label>
            <input name="name" type="text" value={form.name} onChange={handleChange} className="input-field" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-ink mb-1.5">Email address</label>
            <input name="email" type="email" value={form.email} onChange={handleChange} className="input-field" />
          </div>

          <div className="border-t border-surface-muted pt-5">
            <p className="text-sm font-bold text-ink mb-1">Change Password</p>
            <p className="text-xs text-ink-muted mb-4">Leave blank to keep your current password.</p>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-ink mb-1.5">Current password</label>
                <div className="relative">
                  <input name="currentPassword" type={showCurrent ? 'text' : 'password'}
                    value={form.currentPassword} onChange={handleChange}
                    placeholder="Enter current password" className="input-field pr-12" />
                  <button type="button" onClick={() => setShowCurrent(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      {showCurrent
                        ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        : <><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></>
                      }
                    </svg>
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-ink mb-1.5">New password</label>
                <div className="relative">
                  <input name="newPassword" type={showNew ? 'text' : 'password'}
                    value={form.newPassword} onChange={handleChange}
                    placeholder="Min 6 characters" className="input-field pr-12" />
                  <button type="button" onClick={() => setShowNew(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      {showNew
                        ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        : <><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></>
                      }
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2">
              {saving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {saving ? 'Saving…' : 'Save changes'}
            </button>
            <button type="button" onClick={() => {
              setForm({ name: user.name, email: user.email, currentPassword: '', newPassword: '' });
              setError(''); setSuccess('');
            }} className="btn-outline">
              Reset
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
