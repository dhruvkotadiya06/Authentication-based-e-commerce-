import { useState, useEffect } from 'react';
import ProductCard from '../components/ProductCard';

const CATEGORIES = ['All', "men's clothing", "women's clothing", "jewelery", "electronics"];

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('default');

  useEffect(() => {
    setLoading(true);
    fetch('https://fakestoreapi.com/products')
      .then(r => { if (!r.ok) throw new Error('Failed to fetch'); return r.json(); })
      .then(data => { setProducts(data); setLoading(false); })
      .catch(() => { setError('Failed to load products. Please try again.'); setLoading(false); });
  }, []);

  const filtered = products
    .filter(p => category === 'All' || p.category === category)
    .filter(p => p.title.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'price-asc') return a.price - b.price;
      if (sort === 'price-desc') return b.price - a.price;
      if (sort === 'rating') return b.rating.rate - a.rating.rate;
      return 0;
    });

  return (
    <main className="p-6 lg:p-10 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8 animate-slide-up">
        <p className="text-sm text-brand-600 font-semibold mb-1">Catalog</p>
        <h1 className="font-display text-3xl font-bold text-ink">Products</h1>
        <p className="text-ink-muted mt-1">{loading ? 'Loading…' : `${filtered.length} products found`}</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-8 animate-slide-up" style={{ animationDelay: '0.05s' }}>
        {/* Search */}
        <div className="relative flex-1">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input type="text" placeholder="Search products…" value={search} onChange={e => setSearch(e.target.value)}
            className="input-field pl-9" />
        </div>
        {/* Sort */}
        <select value={sort} onChange={e => setSort(e.target.value)} className="input-field sm:w-44">
          <option value="default">Sort: Default</option>
          <option value="price-asc">Price: Low → High</option>
          <option value="price-desc">Price: High → Low</option>
          <option value="rating">Top Rated</option>
        </select>
      </div>

      {/* Category tabs */}
      <div className="flex gap-2 flex-wrap mb-8">
        {CATEGORIES.map(c => (
          <button key={c} onClick={() => setCategory(c)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150 capitalize
              ${category === c ? 'bg-brand-600 text-white shadow-sm' : 'bg-surface-muted text-ink-muted hover:text-ink hover:bg-surface-card'}`}>
            {c}
          </button>
        ))}
      </div>

      {/* States */}
      {error && (
        <div className="card p-8 text-center">
          <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-7 h-7 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
          </div>
          <p className="font-semibold text-ink">{error}</p>
          <button onClick={() => window.location.reload()} className="btn-primary mt-4">Retry</button>
        </div>
      )}

      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="card overflow-hidden">
              <div className="skeleton h-52" />
              <div className="p-5 space-y-3">
                <div className="skeleton h-4 rounded-lg w-full" />
                <div className="skeleton h-4 rounded-lg w-3/4" />
                <div className="skeleton h-8 rounded-xl w-1/2 mt-4" />
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && !error && filtered.length === 0 && (
        <div className="card p-12 text-center">
          <div className="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-brand-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </div>
          <p className="font-semibold text-ink mb-1">No products found</p>
          <p className="text-sm text-ink-muted">Try changing your filters or search term.</p>
          <button onClick={() => { setSearch(''); setCategory('All'); }} className="btn-outline mt-4">Clear filters</button>
        </div>
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((p, i) => (
            <div key={p.id} style={{ animationDelay: `${i * 0.04}s` }}>
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
