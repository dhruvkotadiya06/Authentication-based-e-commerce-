import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';
import { formatTime, SESSION_DURATION } from '../utils/session';

function StatCard({ label, value, sub, color, icon }) {
  return (
    <div className="card p-6 flex items-center gap-4 animate-slide-up">
      <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center shrink-0`}>
        {icon}
      </div>
      <div>
        <p className="text-2xl font-display font-bold text-ink">{value}</p>
        <p className="text-sm font-medium text-ink-muted">{label}</p>
        {sub && <p className="text-xs text-ink-muted/60 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user, sessionRemaining } = useAuth();
  const { items, total, totalItems } = useCart();
  const pct = Math.round((sessionRemaining / SESSION_DURATION) * 100);
  const urgency = sessionRemaining < 60000;

  const quickLinks = [
    { to: '/products', label: 'Browse Products', desc: 'Explore the full catalog', bg: 'bg-brand-600', icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
    )},
    { to: '/cart', label: 'View Cart', desc: `${totalItems} item${totalItems !== 1 ? 's' : ''} · $${total.toFixed(2)}`, bg: 'bg-emerald-600', icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
    )},
    { to: '/profile', label: 'Edit Profile', desc: 'Update your info', bg: 'bg-violet-600', icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
    )},
  ];

  return (
    <main className="p-6 lg:p-10 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-10 animate-slide-up">
        <p className="text-sm text-brand-600 font-semibold mb-1">Dashboard</p>
        <h1 className="font-display text-3xl lg:text-4xl font-bold text-ink">
          Welcome back, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-ink-muted mt-2">Here's a summary of your activity today.</p>
      </div>

      {/* Session timer banner */}
      <div className={`mb-8 card p-5 ${urgency ? 'border-red-200 bg-red-50' : ''} animate-slide-up`} style={{ animationDelay: '0.05s' }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <svg className={`w-5 h-5 ${urgency ? 'text-red-500' : 'text-brand-500'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className={`text-sm font-semibold ${urgency ? 'text-red-700' : 'text-ink'}`}>
              {urgency ? '⚠️ Session expiring soon' : 'Session remaining'}
            </span>
          </div>
          <span className={`font-display text-2xl font-bold tabular-nums ${urgency ? 'text-red-600' : 'text-brand-600'}`}>
            {formatTime(sessionRemaining)}
          </span>
        </div>
        <div className="w-full bg-surface-muted rounded-full h-2 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${urgency ? 'bg-red-400' : 'bg-brand-500'}`}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <StatCard
          label="Cart items"
          value={totalItems}
          color="bg-brand-100"
          icon={<svg className="w-6 h-6 text-brand-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
        />
        <StatCard
          label="Cart total"
          value={`$${total.toFixed(2)}`}
          color="bg-emerald-100"
          icon={<svg className="w-6 h-6 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
        />
        <StatCard
          label="Unique products"
          value={items.length}
          color="bg-violet-100"
          icon={<svg className="w-6 h-6 text-violet-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>}
        />
      </div>

      {/* Quick links */}
      <h2 className="font-display font-bold text-lg text-ink mb-4">Quick Actions</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {quickLinks.map(({ to, label, desc, bg, icon }) => (
          <Link key={to} to={to}
            className="card p-6 flex items-center gap-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group">
            <div className={`w-12 h-12 rounded-2xl ${bg} text-white flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
              {icon}
            </div>
            <div>
              <p className="font-semibold text-ink text-sm">{label}</p>
              <p className="text-xs text-ink-muted mt-0.5">{desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
