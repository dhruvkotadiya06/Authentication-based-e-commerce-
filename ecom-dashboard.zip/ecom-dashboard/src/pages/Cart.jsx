import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

function CartItem({ item, onIncrease, onDecrease, onRemove }) {
  return (
    <div className="card p-4 flex gap-4 items-center animate-fade-in">
      {/* Image */}
      <div className="w-20 h-20 bg-surface rounded-xl flex items-center justify-center shrink-0 p-2">
        <img src={item.image} alt={item.title} className="max-h-full max-w-full object-contain" />
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-ink leading-snug line-clamp-2">{item.title}</p>
        <p className="text-xs text-ink-muted capitalize mt-0.5">{item.category}</p>
        <p className="text-brand-600 font-bold mt-1">${(item.price * item.quantity).toFixed(2)}</p>
      </div>

      {/* Quantity controls */}
      <div className="flex items-center gap-2 shrink-0">
        <button onClick={() => onDecrease(item.id)}
          className="w-8 h-8 rounded-lg bg-surface-muted hover:bg-brand-100 text-ink-muted hover:text-brand-600 flex items-center justify-center transition-all active:scale-90">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M20 12H4" /></svg>
        </button>
        <span className="w-7 text-center font-bold text-sm text-ink tabular-nums">{item.quantity}</span>
        <button onClick={() => onIncrease(item.id)}
          className="w-8 h-8 rounded-lg bg-surface-muted hover:bg-brand-100 text-ink-muted hover:text-brand-600 flex items-center justify-center transition-all active:scale-90">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
        </button>
      </div>

      {/* Remove */}
      <button onClick={() => onRemove(item.id)}
        className="w-8 h-8 rounded-lg text-ink-muted hover:text-red-500 hover:bg-red-50 flex items-center justify-center transition-all active:scale-90 shrink-0">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
      </button>
    </div>
  );
}

export default function Cart() {
  const { items, removeFromCart, increaseQty, decreaseQty, clearCart, total } = useCart();

  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const shipping = subtotal > 50 ? 0 : 4.99;
  const grandTotal = subtotal + shipping;

  if (items.length === 0) {
    return (
      <main className="p-6 lg:p-10 max-w-3xl mx-auto">
        <div className="mb-8 animate-slide-up">
          <p className="text-sm text-brand-600 font-semibold mb-1">Shopping</p>
          <h1 className="font-display text-3xl font-bold text-ink">Your Cart</h1>
        </div>
        <div className="card p-16 text-center animate-fade-in">
          <div className="w-20 h-20 bg-brand-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-brand-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <h2 className="font-display text-xl font-bold text-ink mb-2">Your cart is empty</h2>
          <p className="text-sm text-ink-muted mb-6">Start browsing products and add some to your cart.</p>
          <Link to="/products" className="btn-primary inline-flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
            Browse Products
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="p-6 lg:p-10 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-8 animate-slide-up">
        <div>
          <p className="text-sm text-brand-600 font-semibold mb-1">Shopping</p>
          <h1 className="font-display text-3xl font-bold text-ink">Your Cart</h1>
          <p className="text-ink-muted mt-1">{items.length} product{items.length !== 1 ? 's' : ''} · {items.reduce((s, i) => s + i.quantity, 0)} items</p>
        </div>
        <button onClick={clearCart}
          className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600 font-medium hover:bg-red-50 px-3 py-2 rounded-lg transition-all">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
          Clear all
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Items list */}
        <div className="flex-1 flex flex-col gap-3">
          {items.map(item => (
            <CartItem
              key={item.id}
              item={item}
              onIncrease={increaseQty}
              onDecrease={decreaseQty}
              onRemove={removeFromCart}
            />
          ))}
          <Link to="/products" className="btn-ghost inline-flex items-center gap-2 text-sm mt-2 self-start">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            Continue shopping
          </Link>
        </div>

        {/* Order summary */}
        <div className="lg:w-80 shrink-0">
          <div className="card p-6 sticky top-6">
            <h2 className="font-display font-bold text-lg text-ink mb-5">Order Summary</h2>
            <div className="space-y-3 text-sm">
              {items.map(item => (
                <div key={item.id} className="flex justify-between text-ink-muted">
                  <span className="truncate mr-2 max-w-[160px]">{item.title.substring(0, 24)}…</span>
                  <span className="shrink-0 font-medium text-ink">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t border-surface-muted pt-3 flex justify-between text-ink-muted">
                <span>Subtotal</span>
                <span className="font-semibold text-ink">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-ink-muted">
                <span>Shipping</span>
                <span className={`font-semibold ${shipping === 0 ? 'text-green-600' : 'text-ink'}`}>
                  {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                </span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-brand-600 bg-brand-50 rounded-lg px-3 py-2">
                  Add ${(50 - subtotal).toFixed(2)} more for free shipping!
                </p>
              )}
              <div className="border-t border-surface-muted pt-3 flex justify-between">
                <span className="font-bold text-ink">Total</span>
                <span className="font-display font-bold text-xl text-brand-600">${grandTotal.toFixed(2)}</span>
              </div>
            </div>
            <button className="btn-primary w-full mt-6 flex items-center justify-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Checkout
            </button>
            <p className="text-xs text-center text-ink-muted mt-3">This is a demo — no real purchase</p>
          </div>
        </div>
      </div>
    </main>
  );
}
